import { useState } from "react";
import { LandingPage } from "./components/LandingPage";
import { ShopPage } from "./components/ShopPage";

type Page = "home" | "shop";

export default function App() {
  const [page, setPage] = useState<Page>("home");

  return (
    <div className="size-full">
      {page === "home" ? (
        <LandingPage onShopClick={() => setPage("shop")} />
      ) : (
        <ShopPage onHomeClick={() => setPage("home")} />
      )}
    </div>
  );
}
