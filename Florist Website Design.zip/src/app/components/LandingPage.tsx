import { motion } from "motion/react";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import img1 from "../../imports/WhatsApp_Image_2026-06-10_at_10.51.03__1_.jpeg";
import img2 from "../../imports/WhatsApp_Image_2026-06-10_at_10.51.03.jpeg";
import img3 from "../../imports/WhatsApp_Image_2026-06-10_at_11.16.50.jpeg";
import img4 from "../../imports/WhatsApp_Image_2026-06-10_at_11.16.51.jpeg";

interface LandingPageProps {
  onShopClick: () => void;
}

const floral3D = (
  <svg
    viewBox="0 0 400 400"
    className="w-full h-full"
    xmlns="http://www.w3.org/2000/svg"
  >
    <defs>
      <radialGradient id="petalGrad1" cx="50%" cy="50%" r="50%">
        <stop offset="0%" stopColor="#f9a8c9" />
        <stop offset="100%" stopColor="#8b1a4a" />
      </radialGradient>
      <radialGradient id="petalGrad2" cx="50%" cy="50%" r="50%">
        <stop offset="0%" stopColor="#d4628a" />
        <stop offset="100%" stopColor="#4a0d25" />
      </radialGradient>
      <radialGradient id="centerGrad" cx="50%" cy="50%" r="50%">
        <stop offset="0%" stopColor="#ffecd6" />
        <stop offset="60%" stopColor="#d4628a" />
        <stop offset="100%" stopColor="#6b0f30" />
      </radialGradient>
      <filter id="shadow" x="-20%" y="-20%" width="140%" height="140%">
        <feDropShadow dx="2" dy="4" stdDeviation="8" floodColor="#8b1a4a" floodOpacity="0.6" />
      </filter>
      <filter id="glow">
        <feGaussianBlur stdDeviation="6" result="coloredBlur" />
        <feMerge>
          <feMergeNode in="coloredBlur" />
          <feMergeNode in="SourceGraphic" />
        </feMerge>
      </filter>
    </defs>

    {/* Outer petals ring */}
    {[0, 45, 90, 135, 180, 225, 270, 315].map((angle, i) => {
      const rad = (angle * Math.PI) / 180;
      const cx = 200 + Math.cos(rad) * 120;
      const cy = 200 + Math.sin(rad) * 120;
      return (
        <ellipse
          key={i}
          cx={cx}
          cy={cy}
          rx="38"
          ry="62"
          fill="url(#petalGrad1)"
          transform={`rotate(${angle + 90}, ${cx}, ${cy})`}
          opacity="0.92"
          filter="url(#shadow)"
        />
      );
    })}

    {/* Mid petals ring */}
    {[22.5, 67.5, 112.5, 157.5, 202.5, 247.5, 292.5, 337.5].map((angle, i) => {
      const rad = (angle * Math.PI) / 180;
      const cx = 200 + Math.cos(rad) * 80;
      const cy = 200 + Math.sin(rad) * 80;
      return (
        <ellipse
          key={i}
          cx={cx}
          cy={cy}
          rx="30"
          ry="52"
          fill="url(#petalGrad2)"
          transform={`rotate(${angle + 90}, ${cx}, ${cy})`}
          opacity="0.95"
        />
      );
    })}

    {/* Inner petals ring */}
    {[0, 60, 120, 180, 240, 300].map((angle, i) => {
      const rad = (angle * Math.PI) / 180;
      const cx = 200 + Math.cos(rad) * 44;
      const cy = 200 + Math.sin(rad) * 44;
      return (
        <ellipse
          key={i}
          cx={cx}
          cy={cy}
          rx="22"
          ry="40"
          fill="url(#petalGrad1)"
          transform={`rotate(${angle + 90}, ${cx}, ${cy})`}
          opacity="1"
          filter="url(#glow)"
        />
      );
    })}

    {/* Center */}
    <circle cx="200" cy="200" r="32" fill="url(#centerGrad)" filter="url(#glow)" />
    <circle cx="200" cy="200" r="18" fill="#ffecd6" opacity="0.6" />
    <circle cx="200" cy="200" r="8" fill="#ffffff" opacity="0.9" />

    {/* Sparkles */}
    {[[60, 60], [340, 80], [320, 340], [50, 330], [190, 20], [370, 200]].map(([x, y], i) => (
      <g key={i}>
        <line x1={x - 8} y1={y} x2={x + 8} y2={y} stroke="#f9a8c9" strokeWidth="1.5" opacity="0.7" />
        <line x1={x} y1={y - 8} x2={x} y2={y + 8} stroke="#f9a8c9" strokeWidth="1.5" opacity="0.7" />
        <circle cx={x} cy={y} r="2" fill="#ffffff" opacity="0.9" />
      </g>
    ))}
  </svg>
);

const showcaseItems = [
  { img: img1, label: "Personalised Rose Bouquet", desc: "Crafted with love & your initial" },
  { img: img2, label: "Luxury Rose Bouquet", desc: "50 premium red roses in black wrap" },
  { img: img3, label: "Rose & Chocolate Heart Box", desc: "Roses + Ferrero Rocher gift set" },
  { img: img4, label: "Money Bouquet", desc: "The bouquet that gives back" },
];

export function LandingPage({ onShopClick }: LandingPageProps) {
  return (
    <div className="min-h-screen bg-background text-foreground overflow-x-hidden" style={{ fontFamily: "'Jost', sans-serif" }}>
      {/* Nav */}
      <nav className="fixed top-0 left-0 right-0 z-50 flex items-center justify-between px-6 md:px-12 py-4" style={{ background: "linear-gradient(to bottom, rgba(10,6,8,0.95), transparent)" }}>
        <div style={{ fontFamily: "'Playfair Display', serif", fontSize: "1.1rem", letterSpacing: "0.05em" }}>
          <span style={{ color: "#d4628a" }}>Ruvas</span>
          <span style={{ color: "#f5e8ed" }}> Floral Affection</span>
        </div>
        <div className="flex items-center gap-6">
          <button
            onClick={onShopClick}
            className="px-6 py-2 rounded-full text-sm tracking-widest transition-all duration-300"
            style={{ background: "linear-gradient(135deg, #d4628a, #8b1a4a)", color: "#fff", border: "1px solid rgba(212,98,138,0.4)" }}
            onMouseEnter={e => { (e.target as HTMLButtonElement).style.opacity = "0.85"; }}
            onMouseLeave={e => { (e.target as HTMLButtonElement).style.opacity = "1"; }}
          >
            SHOP NOW
          </button>
        </div>
      </nav>

      {/* Hero */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        {/* Bg glow orbs */}
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-1/3 left-1/4 w-96 h-96 rounded-full" style={{ background: "radial-gradient(circle, rgba(139,26,74,0.25) 0%, transparent 70%)", filter: "blur(40px)" }} />
          <div className="absolute bottom-1/4 right-1/4 w-80 h-80 rounded-full" style={{ background: "radial-gradient(circle, rgba(212,98,138,0.18) 0%, transparent 70%)", filter: "blur(50px)" }} />
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-6 grid md:grid-cols-2 gap-12 items-center py-24">
          {/* Text */}
          <motion.div
            initial={{ opacity: 0, x: -40 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 1, ease: "easeOut" }}
          >
            <p className="tracking-[0.35em] text-xs mb-4" style={{ color: "#d4628a" }}>PREMIUM FLORAL BOUTIQUE</p>
            <h1
              style={{ fontFamily: "'Playfair Display', serif", lineHeight: 1.15, fontSize: "clamp(2.8rem, 6vw, 5rem)", fontWeight: 700, color: "#f5e8ed" }}
            >
              Where Every
              <br />
              <em style={{ color: "#d4628a", fontStyle: "italic" }}>Bloom</em> Tells
              <br />
              a Story
            </h1>
            <p className="mt-6 leading-relaxed" style={{ color: "#9e7a89", maxWidth: "420px", fontWeight: 300 }}>
              Handcrafted bouquets made with passion and precision. From romantic roses to personalised arrangements — we create moments that last forever.
            </p>
            <div className="flex gap-4 mt-10 flex-wrap">
              <button
                onClick={onShopClick}
                className="px-8 py-3 rounded-full tracking-widest text-sm transition-all duration-300 hover:scale-105"
                style={{ background: "linear-gradient(135deg, #d4628a 0%, #8b1a4a 100%)", color: "#fff", boxShadow: "0 8px 32px rgba(139,26,74,0.45)" }}
              >
                ORDER NOW
              </button>
              <button
                className="px-8 py-3 rounded-full tracking-widest text-sm transition-all duration-300 hover:scale-105"
                style={{ border: "1px solid rgba(212,98,138,0.4)", color: "#d4628a", background: "transparent" }}
                onClick={() => document.getElementById("showcase")?.scrollIntoView({ behavior: "smooth" })}
              >
                VIEW COLLECTION
              </button>
            </div>
            {/* Trust badges */}
            <div className="flex gap-8 mt-12">
              {[["100%", "Fresh"], ["24/7", "Orders"], ["Same Day", "Delivery"]].map(([val, label]) => (
                <div key={label}>
                  <div style={{ fontFamily: "'Playfair Display', serif", color: "#d4628a", fontSize: "1.2rem", fontWeight: 700 }}>{val}</div>
                  <div style={{ color: "#9e7a89", fontSize: "0.7rem", letterSpacing: "0.15em" }}>{label.toUpperCase()}</div>
                </div>
              ))}
            </div>
          </motion.div>

          {/* 3D Floral */}
          <motion.div
            initial={{ opacity: 0, scale: 0.7, rotate: -15 }}
            animate={{ opacity: 1, scale: 1, rotate: 0 }}
            transition={{ duration: 1.2, ease: "easeOut" }}
            className="flex items-center justify-center"
          >
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 40, repeat: Infinity, ease: "linear" }}
              className="w-72 h-72 md:w-96 md:h-96"
              style={{ filter: "drop-shadow(0 0 40px rgba(212,98,138,0.5))" }}
            >
              {floral3D}
            </motion.div>
          </motion.div>
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 opacity-50">
          <span style={{ fontSize: "0.65rem", letterSpacing: "0.3em", color: "#d4628a" }}>SCROLL</span>
          <motion.div
            animate={{ y: [0, 8, 0] }}
            transition={{ duration: 1.5, repeat: Infinity }}
            className="w-px h-8"
            style={{ background: "linear-gradient(to bottom, #d4628a, transparent)" }}
          />
        </div>
      </section>

      {/* Showcase / Products Preview */}
      <section id="showcase" className="py-24 px-6">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <p className="tracking-[0.35em] text-xs mb-3" style={{ color: "#d4628a" }}>OUR COLLECTION</p>
            <h2 style={{ fontFamily: "'Playfair Display', serif", fontSize: "clamp(2rem, 4vw, 3rem)", color: "#f5e8ed" }}>
              Signature <em style={{ color: "#d4628a" }}>Arrangements</em>
            </h2>
            <div className="mx-auto mt-4 h-px w-24" style={{ background: "linear-gradient(to right, transparent, #d4628a, transparent)" }} />
          </motion.div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {showcaseItems.map((item, i) => (
              <motion.div
                key={item.label}
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: i * 0.12 }}
                className="group rounded-2xl overflow-hidden cursor-pointer"
                style={{ background: "#130b0f", border: "1px solid rgba(212,98,138,0.12)" }}
                onClick={onShopClick}
              >
                <div className="relative overflow-hidden" style={{ height: "260px" }}>
                  <ImageWithFallback
                    src={item.img}
                    alt={item.label}
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end justify-center pb-6" style={{ background: "linear-gradient(to top, rgba(139,26,74,0.85), transparent)" }}>
                    <span className="text-white text-xs tracking-widest">ORDER NOW →</span>
                  </div>
                </div>
                <div className="p-4">
                  <h3 style={{ fontFamily: "'Playfair Display', serif", color: "#f5e8ed", fontSize: "1rem" }}>{item.label}</h3>
                  <p style={{ color: "#9e7a89", fontSize: "0.78rem", marginTop: "4px" }}>{item.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>

          <div className="text-center mt-12">
            <button
              onClick={onShopClick}
              className="px-10 py-3 rounded-full tracking-widest text-sm transition-all duration-300 hover:scale-105"
              style={{ background: "linear-gradient(135deg, #d4628a 0%, #8b1a4a 100%)", color: "#fff", boxShadow: "0 8px 32px rgba(139,26,74,0.35)" }}
            >
              VIEW ALL & ORDER
            </button>
          </div>
        </div>
      </section>

      {/* Why Us */}
      <section className="py-20 px-6" style={{ background: "linear-gradient(135deg, #0f070d 0%, #130b0f 100%)" }}>
        <div className="max-w-5xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="text-center mb-14"
          >
            <p className="tracking-[0.35em] text-xs mb-3" style={{ color: "#d4628a" }}>THE RUVAS PROMISE</p>
            <h2 style={{ fontFamily: "'Playfair Display', serif", fontSize: "clamp(1.8rem, 3.5vw, 2.6rem)", color: "#f5e8ed" }}>
              Crafted with <em style={{ color: "#d4628a" }}>Love</em> & Precision
            </h2>
          </motion.div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { icon: "✦", title: "Premium Quality", desc: "Every stem hand-selected for freshness and beauty. Only the finest flowers make it into our arrangements." },
              { icon: "♡", title: "Personalised Touch", desc: "From initials spelled in petals to custom colour themes — we make it uniquely yours." },
              { icon: "◈", title: "Easy WhatsApp Order", desc: "No complex checkout. Just tap, choose your arrangement, and confirm via WhatsApp in seconds." },
            ].map((item, i) => (
              <motion.div
                key={item.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: i * 0.15 }}
                className="p-8 rounded-2xl text-center"
                style={{ border: "1px solid rgba(212,98,138,0.14)", background: "rgba(255,255,255,0.02)" }}
              >
                <div className="text-3xl mb-4" style={{ color: "#d4628a" }}>{item.icon}</div>
                <h3 style={{ fontFamily: "'Playfair Display', serif", color: "#f5e8ed", marginBottom: "10px" }}>{item.title}</h3>
                <p style={{ color: "#9e7a89", fontSize: "0.88rem", lineHeight: 1.75 }}>{item.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Banner */}
      <section className="py-24 px-6 relative overflow-hidden">
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute inset-0" style={{ background: "radial-gradient(ellipse at center, rgba(139,26,74,0.2) 0%, transparent 70%)" }} />
        </div>
        <div className="max-w-3xl mx-auto text-center relative z-10">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <p className="tracking-[0.35em] text-xs mb-4" style={{ color: "#d4628a" }}>READY TO ORDER?</p>
            <h2 style={{ fontFamily: "'Playfair Display', serif", fontSize: "clamp(2rem, 4vw, 3.2rem)", color: "#f5e8ed", lineHeight: 1.2 }}>
              Send Someone a Bouquet<br />
              <em style={{ color: "#d4628a" }}>They'll Never Forget</em>
            </h2>
            <p style={{ color: "#9e7a89", marginTop: "1.5rem", fontSize: "0.95rem" }}>
              Handcrafted fresh arrangements • Same-day delivery available • WhatsApp checkout
            </p>
            <button
              onClick={onShopClick}
              className="mt-10 px-12 py-4 rounded-full tracking-widest text-sm transition-all duration-300 hover:scale-105 inline-block"
              style={{ background: "linear-gradient(135deg, #d4628a 0%, #8b1a4a 100%)", color: "#fff", boxShadow: "0 12px 48px rgba(139,26,74,0.5)", fontSize: "0.85rem" }}
            >
              BROWSE & ORDER NOW
            </button>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-10 px-6 text-center" style={{ borderTop: "1px solid rgba(212,98,138,0.1)" }}>
        <div style={{ fontFamily: "'Playfair Display', serif", color: "#d4628a", fontSize: "1.1rem", marginBottom: "6px" }}>Ruvas Floral Affection</div>
        <p style={{ color: "#9e7a89", fontSize: "0.78rem", letterSpacing: "0.1em" }}>
          WhatsApp: +263 778 957 720 · Handcrafted with love
        </p>
        <p style={{ color: "#3d1a28", fontSize: "0.7rem", marginTop: "8px" }}>© 2026 Ruvas Floral Affection. All rights reserved.</p>
      </footer>
    </div>
  );
}
