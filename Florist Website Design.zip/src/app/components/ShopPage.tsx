import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import img1 from "../../imports/WhatsApp_Image_2026-06-10_at_10.51.03__1_.jpeg";
import img2 from "../../imports/WhatsApp_Image_2026-06-10_at_10.51.03.jpeg";
import img3 from "../../imports/WhatsApp_Image_2026-06-10_at_11.16.50.jpeg";
import img4 from "../../imports/WhatsApp_Image_2026-06-10_at_11.16.51.jpeg";

interface Product {
  id: string;
  name: string;
  description: string;
  img: string;
  category: string;
}

const products: Product[] = [
  {
    id: "personalised-rose",
    name: "Personalised Rose Bouquet",
    description: "50 premium red roses with your custom initial spelled in white roses. Beautifully wrapped in white paper.",
    img: img1,
    category: "Roses",
  },
  {
    id: "luxury-rose",
    name: "Luxury Rose Bouquet",
    description: "50+ deep red roses wrapped in signature black organza. The ultimate romantic statement.",
    img: img2,
    category: "Roses",
  },
  {
    id: "heart-box",
    name: "Rose & Chocolate Heart Box",
    description: "Heart-shaped box filled with roses and Ferrero Rocher chocolates. Perfect for special occasions.",
    img: img3,
    category: "Mixed Flowers",
  },
  {
    id: "seasonal-mix",
    name: "Seasonal Mixed Bouquet",
    description: "A vibrant hand-tied arrangement of seasonal blooms in complementary colours. Fresh, lively, and full of life.",
    img: img1,
    category: "Mixed Flowers",
  },
  {
    id: "money-bouquet",
    name: "Money Bouquet",
    description: "A stunning bouquet crafted with folded banknotes and red roses at the centre. A truly unique gift.",
    img: img4,
    category: "Money Bouquet",
  },
];

const categories = ["All", "Roses", "Mixed Flowers", "Money Bouquet", "Custom Order"];

interface CartItem {
  product: Product;
  quantity: number;
}

interface ShopPageProps {
  onHomeClick: () => void;
}

export function ShopPage({ onHomeClick }: ShopPageProps) {
  const [cart, setCart] = useState<Record<string, number>>({});
  const [showConfirm, setShowConfirm] = useState(false);
  const [activeCategory, setActiveCategory] = useState("All");
  const [customNote, setCustomNote] = useState("");

  const updateQty = (id: string, delta: number) => {
    setCart(prev => {
      const current = prev[id] ?? 0;
      const next = Math.max(0, current + delta);
      if (next === 0) {
        const { [id]: _, ...rest } = prev;
        return rest;
      }
      return { ...prev, [id]: next };
    });
  };

  const filteredProducts = activeCategory === "All" || activeCategory === "Custom Order"
    ? products
    : products.filter(p => p.category === activeCategory);

  const cartItems: CartItem[] = products
    .filter(p => (cart[p.id] ?? 0) > 0)
    .map(p => ({ product: p, quantity: cart[p.id] }));

  const hasCustomNote = customNote.trim().length > 0;

  const totalItems = Object.values(cart).reduce((a, b) => a + b, 0);

  const buildWhatsAppMessage = () => {
    const lines = cartItems.map(item => `• ${item.quantity} x ${item.product.name}`).join("\n");
    const customLine = hasCustomNote ? `\n\nCustom request: ${customNote.trim()}` : "";
    const message =
      `Hello Ruvas Floral Affection, I would like to order:\n\n${lines || "(Custom order only)"}${customLine}\n\nPlease assist with delivery details and pricing. Thank you! 🌹`;
    return encodeURIComponent(message);
  };

  const handleFinishOrder = () => {
    if (cartItems.length === 0 && !hasCustomNote) return;
    setShowConfirm(true);
  };

  const confirmOrder = () => {
    const msg = buildWhatsAppMessage();
    window.open(`https://wa.me/263778957720?text=${msg}`, "_blank");
    setShowConfirm(false);
    setCart({});
  };

  return (
    <div className="min-h-screen bg-background text-foreground" style={{ fontFamily: "'Jost', sans-serif" }}>
      {/* Nav */}
      <nav
        className="sticky top-0 z-40 flex items-center justify-between px-6 md:px-12 py-4"
        style={{ background: "rgba(10,6,8,0.95)", backdropFilter: "blur(12px)", borderBottom: "1px solid rgba(212,98,138,0.12)" }}
      >
        <button onClick={onHomeClick} className="flex items-center gap-3 transition-opacity hover:opacity-70">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#d4628a" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M19 12H5M12 5l-7 7 7 7" />
          </svg>
          <span style={{ color: "#9e7a89", fontSize: "0.8rem", letterSpacing: "0.1em" }}>HOME</span>
        </button>

        <div style={{ fontFamily: "'Playfair Display', serif" }}>
          <span style={{ color: "#d4628a" }}>Ruvas</span>
          <span style={{ color: "#f5e8ed" }}> Floral Affection</span>
        </div>

        <div
          className="flex items-center gap-2 px-4 py-1.5 rounded-full"
          style={{ border: "1px solid rgba(212,98,138,0.3)", background: "rgba(139,26,74,0.1)" }}
        >
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="#d4628a" strokeWidth="2">
            <path d="M6 2L3 6v14a2 2 0 002 2h14a2 2 0 002-2V6l-3-4z" /><line x1="3" y1="6" x2="21" y2="6" /><path d="M16 10a4 4 0 01-8 0" />
          </svg>
          <span style={{ color: "#d4628a", fontSize: "0.8rem" }}>{totalItems} items</span>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-6 py-10">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="mb-10"
        >
          <p className="tracking-[0.3em] text-xs mb-2" style={{ color: "#d4628a" }}>HANDCRAFTED FOR YOU</p>
          <h1 style={{ fontFamily: "'Playfair Display', serif", fontSize: "clamp(2rem, 4vw, 3rem)", color: "#f5e8ed" }}>
            Our <em style={{ color: "#d4628a" }}>Collection</em>
          </h1>
          <div className="mt-3 h-px w-16" style={{ background: "linear-gradient(to right, #d4628a, transparent)" }} />
        </motion.div>

        {/* Category Tabs */}
        <div className="flex flex-wrap gap-2 mb-8">
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className="px-5 py-2 rounded-full text-sm tracking-widest transition-all duration-200"
              style={
                activeCategory === cat
                  ? { background: "linear-gradient(135deg, #d4628a, #8b1a4a)", color: "#fff", boxShadow: "0 4px 16px rgba(139,26,74,0.35)" }
                  : { border: "1px solid rgba(212,98,138,0.25)", color: "#9e7a89", background: "transparent" }
              }
            >
              {cat}
            </button>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Products */}
          <div className="lg:col-span-2 space-y-6">
            {/* Custom Order Panel */}
            {activeCategory === "Custom Order" && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                className="rounded-2xl p-6"
                style={{ background: "#130b0f", border: "1px solid rgba(212,98,138,0.25)" }}
              >
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-8 h-8 rounded-full flex items-center justify-center text-base" style={{ background: "linear-gradient(135deg, #d4628a, #8b1a4a)" }}>✦</div>
                  <div>
                    <h3 style={{ fontFamily: "'Playfair Display', serif", color: "#f5e8ed", fontSize: "1.1rem" }}>Custom Order</h3>
                    <p style={{ color: "#9e7a89", fontSize: "0.75rem" }}>Tell us exactly what you have in mind</p>
                  </div>
                </div>
                <p style={{ color: "#9e7a89", fontSize: "0.85rem", lineHeight: 1.7, marginBottom: "16px" }}>
                  Looking for something not in our collection? We can craft a bespoke arrangement just for you — specific flowers, colours, occasions, or personalised messages. Describe your vision below and we'll bring it to life.
                </p>
                <textarea
                  value={customNote}
                  onChange={e => setCustomNote(e.target.value)}
                  placeholder="e.g. Pink and white roses with a pearl trim, wrapped in blush paper, with a card that says 'Happy Birthday Mum'..."
                  rows={5}
                  className="w-full rounded-xl p-4 text-sm resize-none outline-none transition-all duration-200"
                  style={{
                    background: "#0a0608",
                    border: "1px solid rgba(212,98,138,0.2)",
                    color: "#f5e8ed",
                    lineHeight: 1.7,
                  }}
                  onFocus={e => { e.target.style.borderColor = "rgba(212,98,138,0.6)"; }}
                  onBlur={e => { e.target.style.borderColor = "rgba(212,98,138,0.2)"; }}
                />
                {customNote.trim().length > 0 && (
                  <p className="mt-2 text-xs" style={{ color: "#d4628a" }}>
                    ✓ Your custom request will be included in the WhatsApp message
                  </p>
                )}
                <div className="mt-4 p-3 rounded-xl flex items-start gap-3" style={{ background: "rgba(212,98,138,0.05)", border: "1px solid rgba(212,98,138,0.1)" }}>
                  <span style={{ color: "#d4628a", fontSize: "1rem" }}>ℹ</span>
                  <p style={{ color: "#9e7a89", fontSize: "0.78rem", lineHeight: 1.6 }}>
                    You can also add standard products from other categories alongside your custom request — just switch tabs, add items to your order, then come back here.
                  </p>
                </div>
              </motion.div>
            )}

            {/* Mixed Flowers Info Banner */}
            {activeCategory === "Mixed Flowers" && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4 }}
                className="rounded-xl px-5 py-3 flex items-center gap-3"
                style={{ background: "rgba(212,98,138,0.07)", border: "1px solid rgba(212,98,138,0.15)" }}
              >
                <span style={{ color: "#d4628a" }}>🌸</span>
                <p style={{ color: "#9e7a89", fontSize: "0.8rem" }}>
                  Mixed flower arrangements combine seasonal blooms with roses and complementary foliage. Want a bespoke mix? Try our <button onClick={() => setActiveCategory("Custom Order")} style={{ color: "#d4628a", background: "none", border: "none", cursor: "pointer", padding: 0, fontSize: "0.8rem" }}>Custom Order</button> tab.
                </p>
              </motion.div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            {filteredProducts.map((product, i) => {
              const qty = cart[product.id] ?? 0;
              return (
                <motion.div
                  key={product.id}
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: i * 0.1 }}
                  className="rounded-2xl overflow-hidden flex flex-col"
                  style={{ background: "#130b0f", border: qty > 0 ? "1px solid rgba(212,98,138,0.5)" : "1px solid rgba(212,98,138,0.1)", transition: "border-color 0.3s" }}
                >
                  <div className="relative overflow-hidden" style={{ height: "220px" }}>
                    <ImageWithFallback
                      src={product.img}
                      alt={product.name}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute top-3 left-3">
                      <span
                        className="px-3 py-1 rounded-full text-xs tracking-widest"
                        style={{ background: "rgba(10,6,8,0.8)", color: "#d4628a", border: "1px solid rgba(212,98,138,0.3)" }}
                      >
                        {product.category}
                      </span>
                    </div>
                    {qty > 0 && (
                      <div className="absolute top-3 right-3 w-7 h-7 rounded-full flex items-center justify-center text-xs" style={{ background: "#d4628a", color: "#fff", fontWeight: 600 }}>
                        {qty}
                      </div>
                    )}
                  </div>

                  <div className="p-5 flex flex-col flex-1">
                    <h3 style={{ fontFamily: "'Playfair Display', serif", color: "#f5e8ed", fontSize: "1rem", marginBottom: "6px" }}>
                      {product.name}
                    </h3>
                    <p style={{ color: "#9e7a89", fontSize: "0.78rem", lineHeight: 1.6, flex: 1 }}>{product.description}</p>

                    {/* Quantity control */}
                    <div className="mt-4 flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <button
                          onClick={() => updateQty(product.id, -1)}
                          disabled={qty === 0}
                          className="w-8 h-8 rounded-full flex items-center justify-center text-lg transition-all"
                          style={{
                            border: "1px solid rgba(212,98,138,0.4)",
                            color: qty === 0 ? "#3d1a28" : "#d4628a",
                            background: "transparent",
                            cursor: qty === 0 ? "not-allowed" : "pointer",
                          }}
                        >
                          −
                        </button>
                        <span style={{ color: "#f5e8ed", minWidth: "24px", textAlign: "center", fontSize: "1rem" }}>{qty}</span>
                        <button
                          onClick={() => updateQty(product.id, 1)}
                          className="w-8 h-8 rounded-full flex items-center justify-center text-lg transition-all hover:scale-110"
                          style={{ background: "linear-gradient(135deg, #d4628a, #8b1a4a)", color: "#fff" }}
                        >
                          +
                        </button>
                      </div>
                      {qty === 0 && (
                        <button
                          onClick={() => updateQty(product.id, 1)}
                          className="text-xs tracking-widest transition-opacity hover:opacity-70"
                          style={{ color: "#d4628a" }}
                        >
                          ADD TO ORDER →
                        </button>
                      )}
                    </div>
                  </div>
                </motion.div>
              );
            })}
            </div>
          </div>

          {/* Cart Summary */}
          <div className="lg:col-span-1">
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
              className="sticky top-24 rounded-2xl p-6"
              style={{ background: "#130b0f", border: "1px solid rgba(212,98,138,0.15)" }}
            >
              <div className="flex items-center gap-2 mb-6">
                <div className="w-2 h-2 rounded-full" style={{ background: "#d4628a" }} />
                <h2 style={{ fontFamily: "'Playfair Display', serif", color: "#f5e8ed", fontSize: "1.1rem" }}>Your Order</h2>
              </div>

              <AnimatePresence>
                {cartItems.length === 0 ? (
                  <motion.div
                    key="empty"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="text-center py-10"
                  >
                    <div className="text-4xl mb-3">🌹</div>
                    <p style={{ color: "#9e7a89", fontSize: "0.85rem" }}>Your order is empty.</p>
                    <p style={{ color: "#3d1a28", fontSize: "0.75rem", marginTop: "4px" }}>Add flowers above to begin</p>
                  </motion.div>
                ) : (
                  <motion.div key="items" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                    <div className="space-y-3 mb-6">
                      {cartItems.map(item => (
                        <motion.div
                          key={item.product.id}
                          initial={{ opacity: 0, x: 10 }}
                          animate={{ opacity: 1, x: 0 }}
                          exit={{ opacity: 0, x: -10 }}
                          className="flex items-center gap-3 p-3 rounded-xl"
                          style={{ background: "rgba(212,98,138,0.06)", border: "1px solid rgba(212,98,138,0.1)" }}
                        >
                          <div className="w-12 h-12 rounded-lg overflow-hidden flex-shrink-0">
                            <ImageWithFallback
                              src={item.product.img}
                              alt={item.product.name}
                              className="w-full h-full object-cover"
                            />
                          </div>
                          <div className="flex-1 min-w-0">
                            <p style={{ color: "#f5e8ed", fontSize: "0.82rem", fontWeight: 500 }} className="truncate">{item.product.name}</p>
                            <p style={{ color: "#9e7a89", fontSize: "0.72rem" }}>Qty: {item.quantity}</p>
                          </div>
                          <button
                            onClick={() => setCart(prev => { const { [item.product.id]: _, ...rest } = prev; return rest; })}
                            className="text-xs opacity-40 hover:opacity-100 transition-opacity"
                            style={{ color: "#d4628a" }}
                          >
                            ✕
                          </button>
                        </motion.div>
                      ))}
                    </div>

                    {hasCustomNote && (
                      <div className="mb-3 rounded-xl p-3" style={{ background: "rgba(212,98,138,0.07)", border: "1px solid rgba(212,98,138,0.15)" }}>
                        <p style={{ color: "#d4628a", fontSize: "0.72rem", marginBottom: "4px" }}>✦ Custom request included</p>
                        <p style={{ color: "#9e7a89", fontSize: "0.72rem", lineHeight: 1.5 }} className="line-clamp-2">{customNote.trim()}</p>
                      </div>
                    )}
                    <div className="pt-4 mb-6" style={{ borderTop: "1px solid rgba(212,98,138,0.12)" }}>
                      <div className="flex justify-between items-center">
                        <span style={{ color: "#9e7a89", fontSize: "0.82rem" }}>Total items</span>
                        <span style={{ color: "#d4628a", fontWeight: 600 }}>{totalItems}</span>
                      </div>
                      <p style={{ color: "#9e7a89", fontSize: "0.72rem", marginTop: "6px", lineHeight: 1.5 }}>
                        Final pricing will be confirmed via WhatsApp.
                      </p>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>

              {/* WhatsApp Button */}
              <button
                onClick={handleFinishOrder}
                disabled={cartItems.length === 0 && !hasCustomNote}
                className="w-full py-4 rounded-xl tracking-widest text-sm transition-all duration-300 flex items-center justify-center gap-3"
                style={{
                  background: (cartItems.length === 0 && !hasCustomNote) ? "#1e0e15" : "linear-gradient(135deg, #25D366 0%, #128C7E 100%)",
                  color: (cartItems.length === 0 && !hasCustomNote) ? "#3d1a28" : "#fff",
                  cursor: (cartItems.length === 0 && !hasCustomNote) ? "not-allowed" : "pointer",
                  boxShadow: (cartItems.length > 0 || hasCustomNote) ? "0 8px 24px rgba(37,211,102,0.25)" : "none",
                }}
              >
                <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
                </svg>
                FINISH ORDER VIA WHATSAPP
              </button>

              {cartItems.length === 0 && !hasCustomNote && (
                <p className="text-center mt-3" style={{ color: "#3d1a28", fontSize: "0.72rem" }}>Add items or write a custom request first</p>
              )}
            </motion.div>
          </div>
        </div>
      </div>

      {/* Confirm Modal */}
      <AnimatePresence>
        {showConfirm && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-6"
            style={{ background: "rgba(0,0,0,0.85)", backdropFilter: "blur(8px)" }}
            onClick={() => setShowConfirm(false)}
          >
            <motion.div
              initial={{ scale: 0.85, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.85, opacity: 0 }}
              transition={{ type: "spring", stiffness: 300, damping: 25 }}
              className="max-w-md w-full rounded-2xl p-8"
              style={{ background: "#130b0f", border: "1px solid rgba(212,98,138,0.3)" }}
              onClick={e => e.stopPropagation()}
            >
              <div className="text-center mb-6">
                <div className="text-4xl mb-3">🌹</div>
                <h3 style={{ fontFamily: "'Playfair Display', serif", color: "#f5e8ed", fontSize: "1.3rem", marginBottom: "8px" }}>
                  Confirm Your Order
                </h3>
                <p style={{ color: "#9e7a89", fontSize: "0.85rem" }}>
                  You'll be redirected to WhatsApp to confirm details & delivery with us.
                </p>
              </div>

              <div className="mb-6 rounded-xl p-4 space-y-2" style={{ background: "rgba(212,98,138,0.06)", border: "1px solid rgba(212,98,138,0.1)" }}>
                {cartItems.length === 0 && hasCustomNote && (
                  <p style={{ color: "#9e7a89", fontSize: "0.82rem", fontStyle: "italic" }}>Custom order only</p>
                )}
                {cartItems.map(item => (
                  <div key={item.product.id} className="flex justify-between items-center">
                    <span style={{ color: "#f5e8ed", fontSize: "0.85rem" }}>{item.product.name}</span>
                    <span style={{ color: "#d4628a", fontSize: "0.85rem" }}>× {item.quantity}</span>
                  </div>
                ))}
                {hasCustomNote && (
                  <div className="pt-2" style={{ borderTop: cartItems.length > 0 ? "1px solid rgba(212,98,138,0.15)" : "none" }}>
                    <p style={{ color: "#9e7a89", fontSize: "0.75rem", marginBottom: "4px" }}>Custom request:</p>
                    <p style={{ color: "#f5e8ed", fontSize: "0.8rem", fontStyle: "italic", lineHeight: 1.5 }}>{customNote.trim()}</p>
                  </div>
                )}
                {totalItems > 0 && (
                  <div className="pt-2 flex justify-between items-center" style={{ borderTop: "1px solid rgba(212,98,138,0.15)" }}>
                    <span style={{ color: "#9e7a89", fontSize: "0.8rem" }}>Total items</span>
                    <span style={{ color: "#d4628a", fontWeight: 600 }}>{totalItems}</span>
                  </div>
                )}
              </div>

              <div className="flex gap-3">
                <button
                  onClick={() => setShowConfirm(false)}
                  className="flex-1 py-3 rounded-xl text-sm transition-all"
                  style={{ border: "1px solid rgba(212,98,138,0.2)", color: "#9e7a89", background: "transparent" }}
                >
                  Cancel
                </button>
                <button
                  onClick={confirmOrder}
                  className="flex-1 py-3 rounded-xl text-sm flex items-center justify-center gap-2 transition-all hover:scale-105"
                  style={{ background: "linear-gradient(135deg, #25D366 0%, #128C7E 100%)", color: "#fff" }}
                >
                  <svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
                  </svg>
                  Open WhatsApp
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
