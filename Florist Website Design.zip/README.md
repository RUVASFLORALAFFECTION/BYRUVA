
  # Florist Website Design

  This is a code bundle for Florist Website Design. The original project is available at https://www.figma.com/design/K9fuLMUPRMPMC7eL4f9DtH/Florist-Website-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  